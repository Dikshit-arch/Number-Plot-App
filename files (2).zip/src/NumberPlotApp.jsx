import React, { useState, useEffect } from "react";
import { LineChart, Line, CartesianGrid, XAxis, YAxis, Tooltip } from "recharts";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

const NumberPlotApp = () => {
  const [inputValue, setInputValue] = useState("");
  const [description, setDescription] = useState("");
  const [data, setData] = useState([]);
  const [redoStack, setRedoStack] = useState([]);
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().slice(0, 10));

  useEffect(() => {
    const savedData = localStorage.getItem("graphData");
    if (savedData) {
      setData(JSON.parse(savedData));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem("graphData", JSON.stringify(data));
  }, [data]);

  const handleAddPoint = () => {
    const number = parseFloat(inputValue);

    if (isNaN(number) || number < -100 || number > 100) {
      alert("Please enter a number between -100 and +100.");
      return;
    }

    const newPoint = {
      date: new Date(selectedDate).toLocaleDateString(),
      time: new Date().toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", hour12: true }),
      day: new Date(selectedDate).toLocaleString("en-us", { weekday: "long" }),
      value: number,
      description: description,
    };

    setData((prevData) => [...prevData, newPoint]);
    setRedoStack([]);
    setInputValue("");
    setDescription("");
  };

  const handleUndo = () => {
    if (data.length === 0) return;
    setRedoStack((prevRedo) => [data[data.length - 1], ...prevRedo]);
    setData((prevData) => prevData.slice(0, -1));
  };

  const handleRedo = () => {
    if (redoStack.length === 0) return;
    const lastRedo = redoStack[0];
    setRedoStack((prevRedo) => prevRedo.slice(1));
    setData((prevData) => [...prevData, lastRedo]);
  };

  const categorizedData = data.map((point) => {
    const date = new Date(point.date);
    const month = date.toLocaleString("en-us", { month: "long" });
    const day = date.getDate();
    const year = date.getFullYear();

    return {
      ...point,
      name: `${month} ${day}, ${year}`,
    };
  });

  const groupedData = Object.values(
    categorizedData.reduce((acc, point) => {
      const date = new Date(point.date);
      const monthYear = date.toLocaleString("en-us", { month: "long", year: "numeric" });

      if (!acc[monthYear]) {
        acc[monthYear] = { monthYear, points: [] };
      }

      acc[monthYear].points.push(point);
      return acc;
    }, {})
  );

  const customTooltip = ({ active, payload }) => {
    if (active && payload && payload.length) {
      const { name, value, description } = payload[0].payload;
      return (
        <div className="p-2 bg-gray-800 text-gray-300 rounded">
          <p>{name}</p>
          <p>Value: {value}</p>
          <p>Description: {description || "No description"}</p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="min-h-screen bg-black text-gray-300 flex flex-col items-center justify-center p-6">
      <Card className="w-full max-w-4xl p-4 bg-gray-900 border border-gray-700">
        <CardContent>
          <h1 className="text-xl font-bold mb-4 text-center">Cracker System Graph</h1>
          <div className="flex flex-col items-center gap-4">
            <Input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="bg-gray-800 text-gray-300 border border-gray-600"
            />
            <Input
              type="number"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder="Enter a number (-100 to +100)"
              className="bg-gray-800 text-gray-300 border border-gray-600"
            />
            <Input
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Enter a description"
              className="bg-gray-800 text-gray-300 border border-gray-600"
            />
            <div className="flex gap-2">
              <Button onClick={handleAddPoint} className="bg-gray-700 text-gray-300 hover:bg-gray-600">
                Add Point
              </Button>
              <Button onClick={handleUndo} className="bg-gray-700 text-gray-300 hover:bg-gray-600">
                Undo Last
              </Button>
              <Button onClick={handleRedo} className="bg-gray-700 text-gray-300 hover:bg-gray-600">
                Redo Last
              </Button>
            </div>
          </div>
          <div className="mt-6">
            {groupedData.map(({ monthYear, points }) => (
              <div key={monthYear} className="mb-6">
                <h2 className="text-lg font-bold mb-2">{monthYear}</h2>
                <LineChart
                  width={800}
                  height={300}
                  data={points}
                  margin={{ top: 20, right: 10, left: 10, bottom: 50 }}
                >
                  <CartesianGrid stroke="#555" strokeDasharray="5 5" />
                  <XAxis
                    dataKey="name"
                    stroke="#aaa"
                    interval={0}
                    tickFormatter={(value) => value.split(" ")[1].replace(",", "")}
                    textAnchor="middle"
                  />
                  <YAxis
                    stroke="#aaa"
                    domain={[-100, 100]}
                    ticks={Array.from({ length: 21 }, (_, i) => 100 - i * 10)}
                    allowDataOverflow={false}
                  />
                  <Tooltip content={customTooltip} wrapperStyle={{ backgroundColor: "#222", color: "#aaa" }} />
                  <Line type="monotone" dataKey="value" stroke="#aaa" strokeWidth={2} />
                </LineChart>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default NumberPlotApp;