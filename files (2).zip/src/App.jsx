import React from "react";
import NumberPlotApp from "./NumberPlotApp";

function App() {
  return <NumberPlotApp />;
}

export default App;